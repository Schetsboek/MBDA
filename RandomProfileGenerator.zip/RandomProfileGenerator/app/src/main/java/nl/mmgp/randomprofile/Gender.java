package nl.mmgp.randomprofile;

public enum Gender {
    Male,
    Female
}
