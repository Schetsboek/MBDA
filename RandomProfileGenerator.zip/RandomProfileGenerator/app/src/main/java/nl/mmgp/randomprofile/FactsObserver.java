package nl.mmgp.randomprofile;

public interface FactsObserver {
    void getFact(String fact);
}
